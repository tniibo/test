# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## プロジェクト概要

Next.js 15を使用したWizシリーズ製品ポータルアプリケーション。キーボードショートカット（Ctrl+Q）でリアルタイムに切り替え可能な3つのデザインテーマを実装している。レスポンシブなヘッダー、開閉可能なサイドバーナビゲーション、AIチャット機能、デザインショーケース、Wizシリーズ製品紹介を含む統合ポータルシステム。

## コマンド

### 開発
```bash
# 開発サーバーの起動（Turbopack使用）
npm run dev

# プロダクションビルド
npm run build

# プロダクションサーバーの起動
npm run start

# ESLintの実行
npm run lint
```

### 開発サーバー
- デフォルトポート: http://localhost:3000
- Turbopack使用で高速な開発体験

## アーキテクチャと主要パターン

### アプリケーション構造
- **Next.js App Router**: `/app`ディレクトリによるファイルベースルーティング
- **単一ページアプリケーション**: `app/page.tsx`で`currentPage`状態によるページ切り替え管理
- **クライアントコンポーネント**: ブラウザAPIを必要とするコンポーネントは`'use client'`ディレクティブを使用

### コンポーネント設計
- **Header**: ユーザーアイコン、ナビゲーション、ドロップダウンメニュー
- **Sidebar**: ページ切り替え用メニュー（ホーム、AIチャット、Wizシリーズ、設定）
- **FeatureCard**: ホーム画面のカード型メニュー
- **AIChat**: リアルタイム風チャットインターフェース（neko.PNGをAIアイコンとして使用）
- **DesignShowcase**: UI コンポーネント（ボタン、テーブル、プルダウン、カード）のプレビュー
- **WizSeries**: フリップカード風の製品紹介（SVGアイコン使用）

### アイコンシステム
CSS maskプロパティを使用したアイコンシステム：
- **ベースクラス**: `.icon` + サイズバリエーション（`.icon-sm`, `.icon-md`, `.icon-lg`）
- **アイコン定義**: 各テーマファイル（concept1.css, concept2.css）に統一されたアイコンセットを定義
- **利用可能アイコン**: plus, settings, trash, save, ban, eye, edit, add, upload
- **実装**: `<span className="icon icon-plus"></span>`形式で使用
- **テーマ対応**: currentColorを使用してテーマの色が自動適用

### テーマシステム
キーボード操作による3つのテーマ切り替えシステム：

- **テーマ状態管理**: `app/page.tsx`でReact hooksを使用
- **テーマ切り替え**: Ctrl+Qキーボードショートカットでテーマをトグル
- **CSS設計**: 
  - `app/globals.css`で全テーマファイルをインポート
  - `styles/concept1.css`: 誰でも利用しやすいレイアウト（ライトテーマ）
  - `styles/concept2.css`: 魔法をイメージしたデザイン（群青色ベースのダークテーマ）
  - `styles/concept3.css`: 神秘的な魔法テーマ（cardImage.png背景使用予定）
  - CSS カスタムプロパティによる動的スタイリング

### Wizシリーズ製品
6つの製品を3×2グリッドレイアウトで表示：
- **Wiz-Grimoire** (グリーン): ユーザーツール埋め込みAPI
- **Wiz-Chronicle** (オレンジ): プロジェクトマネージメントツール  
- **Wiz-COBOL** (紫): COBOLエディタ
- **Wiz-Lore** (濃いみどり): 魔法知識データベース
- **Wiz-Sprite** (ブルー): 魔法精霊アシスタント
- **Wiz-Plugins** (濃いブルー): 魔法拡張プラグインシステム

各製品にはSVGアイコンが設定され、`public/`ディレクトリに配置されている。

### ページナビゲーションシステム
- **状態ベースルーティング**: `currentPage`状態による画面切り替え
- **サイドバーナビゲーション**: 各メニュー項目が`onPageChange`コールバックを呼び出し
- **利用可能ページ**: home, ai-chat, settings, wiz-series

### ユーザー設定機能
- **フォントサイズ調整**: 小・中・大の3段階、CSS変数による全体適用
- **テーマ切り替え**: ユーザーアカウント設定モーダルから変更可能
- **設定の永続化**: React状態管理（リロード時は初期値に戻る）

### スタイリング手法
- **Tailwind CSS v3**: ユーティリティクラスによる高速開発
- **カスタムCSS**: CSS カスタムプロパティを使用したテーマ固有のスタイル
- **PostCSS**: TailwindとAutoprefixerによる処理パイプライン
- **フリップカードアニメーション**: 3D変形エフェクト

### 実装上の重要点

1. **テーマ適用**: `page.tsx`のルートdivにテーマ状態に基づく動的classNameを適用
2. **フォントサイズ適用**: ルートdivに`font-size-${fontSize}`クラスを適用してグローバル制御
3. **アイコン追加**: 新しいアイコンを追加する場合は両方のテーマファイル（concept1.css, concept2.css）に定義が必要
4. **CSSインポート順序**: パースエラーを避けるため、テーマCSSファイルはTailwindディレクティブより前にインポート
5. **画像アセット**: SVGアイコンとPNG画像は`public/`ディレクトリに配置し、絶対パスでアクセス

## 特殊機能

### AIチャット
- リアルタイムメッセージ交換インターフェース
- AIアイコンに`neko.PNG`を使用（丸枠で表示）
- ユーザーアイコンは青い円背景に「U」
- 模擬AI応答（setTimeout使用）

### デザインショーケース
- ボタン、テーブル、プルダウン、ラジオボタン、チェックボックス、カードの各UIコンポーネント表示
- 全ボタンにアイコンシステムを使用したアイコン付きボタンを実装
- 新規追加、編集、アップロードボタンを含む

### Wizシリーズ
- 書籍風フリップカードアニメーション
- 6つの製品（Grimoire, Chronicle, COBOL, Lore, Sprite, Plugins）
- 3Dトランスフォームによるホバー効果
- concept2テーマでは古代魔導書風の3D立体デザイン

## concept3テーマについて
`concept3.md`にconcept3テーマの実装要件が記載されている：
- フィーチャーカードに`cardImage.png`背景画像を設定
- 正方形（1:1）アスペクト比
- ::after疑似要素使用で背景配置（z-index: 0）
- コンテンツを前面配置（z-index: 1）
- 画像透明度0.7で視認性確保

## 開発上の注意点

- **Node.js要件**: 最小バージョン 18.0.0
- **TypeScript**: strictモード有効の完全なTypeScriptサポート
- **パスエイリアス**: プロジェクトルートからのインポートには`@/*`を使用
- **Turbopack**: 開発サーバーは高速ビルドのためTurbopackを使用
- **静的ファイル**: 画像やSVGファイルは`public/`ディレクトリに配置