'use client'

import { useState, useEffect } from 'react'
import Header from '@/components/Header'
import Sidebar from '@/components/Sidebar'
import FeatureCard from '@/components/FeatureCard'
import AIChat from '@/components/AIChat'
import DesignShowcase from '@/components/DesignShowcase'
import WizSeries from '@/components/WizSeries'
import AccountSettingsModal from '@/components/AccountSettingsModal'

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [theme, setTheme] = useState('concept1')
  const [currentPage, setCurrentPage] = useState('home')
  const [fontSize, setFontSize] = useState('medium')
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false)

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'q') {
        setTheme(prev => {
          if (prev === 'concept1') return 'concept2'
          if (prev === 'concept2') return 'concept3'
          return 'concept1'
        })
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [])

  const handleFeatureClick = (feature: string) => {
    if (feature === 'ai-chat') {
      setCurrentPage('ai-chat')
    } else if (feature === 'settings') {
      setCurrentPage('settings')
    }
  }

  return (
    <div className={`min-h-screen ${theme} font-size-${fontSize}`}>
      <Header 
        onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} 
        onSettingsClick={() => setIsSettingsModalOpen(true)}
      />
      <div className="flex">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onPageChange={setCurrentPage}
          currentPage={currentPage}
        />
        <main className={`flex-1 p-6 transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-0'}`}>
          {currentPage === 'home' ? (
            <>
              <h1 className="text-2xl font-bold mb-4">ポータル画面</h1>
              <p className="mb-4">現在のテーマ: {
                theme === 'concept1' ? 'デザインコンセプト１（誰でも利用しやすいレイアウト）' : 
                theme === 'concept2' ? 'デザインコンセプト２（魔法をイメージしたデザイン）' : 
                'デザインコンセプト３（神秘的な魔法テーマ）'
              }</p>
              <p className="text-sm text-gray-600 mb-8">Ctrl + Qでテーマを切り替えできます</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div onClick={() => handleFeatureClick('ai-chat')}>
                  <FeatureCard
                    title="AIチャット"
                    description="AIアシスタントと対話できます"
                    icon="🤖"
                    route="#"
                    color="bg-indigo-500 text-white"
                    cardType="ai-chat"
                  />
                </div>
                <FeatureCard
                  title="ドキュメントの登録（RAG）"
                  description="ドキュメントをAIに学習させて活用できます"
                  icon="📚"
                  route="/rag-docs"
                  color="bg-blue-500 text-white"
                  cardType="rag-docs"
                />
                <FeatureCard
                  title="PG翻訳ツール"
                  description="プログラムコードを別言語に翻訳します"
                  icon="💻"
                  route="/pg-translator"
                  color="bg-teal-500 text-white"
                  cardType="pg-translator"
                />
                <div onClick={() => handleFeatureClick('settings')}>
                  <FeatureCard
                    title="設定"
                    description="システムの各種設定を管理します"
                    icon="⚙️"
                    route="#"
                    color="bg-orange-500 text-white"
                    cardType="settings"
                  />
                </div>
                <FeatureCard
                  title="ユーザー管理"
                  description="ユーザーの登録、編集、権限管理を行います"
                  icon="👥"
                  route="/users"
                  color="bg-green-500 text-white"
                  cardType="users"
                />
                <FeatureCard
                  title="レポート"
                  description="各種レポートの作成と出力が可能です"
                  icon="📈"
                  route="/reports"
                  color="bg-purple-500 text-white"
                  cardType="reports"
                />
              </div>
            </>
          ) : currentPage === 'ai-chat' ? (
            <div className="h-full">
              <div className="flex items-center mb-4">
                <h1 className="text-2xl font-bold">AIチャット</h1>
              </div>
              <div className="h-[calc(100vh-160px)]">
                <AIChat />
              </div>
            </div>
          ) : currentPage === 'settings' ? (
            <div>
              <div className="flex items-center mb-6">
                <h1 className="text-2xl font-bold">デザインショーケース</h1>
              </div>
              <p className="text-sm text-gray-600 mb-6">各UIコンポーネントのデザインを確認できます</p>
              <DesignShowcase />
            </div>
          ) : currentPage === 'wiz-series' ? (
            <div>
              <div className="flex items-center mb-6">
                <h1 className="text-2xl font-bold">Wizシリーズ</h1>
              </div>
              <WizSeries />
            </div>
          ) : null}
        </main>
      </div>
      
      <AccountSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        currentTheme={theme}
        onThemeChange={setTheme}
        currentFontSize={fontSize}
        onFontSizeChange={setFontSize}
      />
    </div>
  )
}