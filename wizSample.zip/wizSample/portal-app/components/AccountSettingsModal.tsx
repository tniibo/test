'use client'

import { useState, useEffect } from 'react'

interface AccountSettingsModalProps {
  isOpen: boolean
  onClose: () => void
  currentTheme: string
  onThemeChange: (theme: string) => void
  currentFontSize: string
  onFontSizeChange: (fontSize: string) => void
}

export default function AccountSettingsModal({ 
  isOpen, 
  onClose, 
  currentTheme, 
  onThemeChange,
  currentFontSize,
  onFontSizeChange
}: AccountSettingsModalProps) {
  const [tempTheme, setTempTheme] = useState(currentTheme)
  const [tempFontSize, setTempFontSize] = useState(currentFontSize)

  useEffect(() => {
    setTempTheme(currentTheme)
    setTempFontSize(currentFontSize)
  }, [currentTheme, currentFontSize, isOpen])

  const handleSave = () => {
    onThemeChange(tempTheme)
    onFontSizeChange(tempFontSize)
    onClose()
  }

  const handleCancel = () => {
    setTempTheme(currentTheme)
    setTempFontSize(currentFontSize)
    onClose()
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleCancel()
    }
  }

  if (!isOpen) return null

  return (
    <div 
      className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]"
      onClick={handleBackdropClick}
    >
      <div className="modal-container bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
        <div className="modal-header flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold modal-title">アカウント設定</h2>
          <button
            onClick={handleCancel}
            className="modal-close-btn text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="modal-body p-6 space-y-6">
          {/* フォントサイズ設定 */}
          <div className="setting-group">
            <label className="block text-sm font-medium mb-3 setting-label">フォントサイズ</label>
            <div className="space-y-2">
              {[
                { value: 'small', label: '小', description: '読みやすい小さめのフォント' },
                { value: 'medium', label: '中', description: '標準的なフォントサイズ' },
                { value: 'large', label: '大', description: '見やすい大きめのフォント' }
              ].map((option) => (
                <label key={option.value} className="font-size-option flex items-center p-3 rounded cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="fontSize"
                    value={option.value}
                    checked={tempFontSize === option.value}
                    onChange={(e) => setTempFontSize(e.target.value)}
                    className="mr-3 accent-blue-500"
                  />
                  <div>
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500">{option.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* デザインテーマ設定 */}
          <div className="setting-group">
            <label className="block text-sm font-medium mb-3 setting-label">デザインテーマ</label>
            <div className="space-y-2">
              {[
                { value: 'concept1', label: 'ライトテーマ', description: '誰でも利用しやすいレイアウト' },
                { value: 'concept2', label: 'ダークテーマ', description: '魔法をイメージしたデザイン' },
                { value: 'concept3', label: '神秘的魔法テーマ', description: '深海の青を基調とした神秘的なテーマ' }
              ].map((option) => (
                <label key={option.value} className="theme-option flex items-center p-3 rounded cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="theme"
                    value={option.value}
                    checked={tempTheme === option.value}
                    onChange={(e) => setTempTheme(e.target.value)}
                    className="mr-3 accent-blue-500"
                  />
                  <div className="flex-1">
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500">{option.description}</div>
                  </div>
                  <div className={`theme-preview w-6 h-6 rounded border-2 ${
                    option.value === 'concept1' 
                      ? 'bg-white border-gray-300' 
                      : option.value === 'concept2'
                      ? 'bg-slate-800 border-blue-400'
                      : 'bg-amber-100 border-amber-600'
                  }`}></div>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="modal-footer flex justify-end space-x-3 p-6 border-t">
          <button
            onClick={handleCancel}
            className="modal-cancel-btn px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleSave}
            className="modal-save-btn px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
          >
            保存
          </button>
        </div>
      </div>
    </div>
  )
}