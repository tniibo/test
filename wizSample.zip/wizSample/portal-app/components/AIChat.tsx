'use client'

import { useState } from 'react'
import Image from 'next/image'

interface Message {
  id: number
  text: string
  sender: 'user' | 'ai'
  timestamp: Date
}

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: 'こんにちは！AIアシスタントです。何かお手伝いできることはありますか？',
      sender: 'ai',
      timestamp: new Date()
    }
  ])
  const [inputText, setInputText] = useState('')

  const handleSendMessage = () => {
    if (inputText.trim() === '') return

    const newUserMessage: Message = {
      id: messages.length + 1,
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    }

    setMessages([...messages, newUserMessage])
    setInputText('')

    setTimeout(() => {
      const aiResponse: Message = {
        id: messages.length + 2,
        text: 'ご質問ありがとうございます。こちらはデモ用のレスポンスです。',
        sender: 'ai',
        timestamp: new Date()
      }
      setMessages(prev => [...prev, aiResponse])
    }, 1000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="ai-chat-container h-full flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className="message w-full"
          >
            <div className="flex items-start gap-3 w-full">
              {message.sender === 'ai' && (
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center">
                  <div className="w-full h-full bg-gray-200 rounded-full overflow-hidden">
                    <Image
                      src="/neko.svg"
                      alt="AI Assistant"
                      width={48}
                      height={48}
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              )}
              
              {message.sender === 'user' && (
                <div className="w-12 h-12 flex-shrink-0"></div>
              )}
              
              <div
                className={`message-bubble flex-1 px-4 py-2 rounded-lg ${
                  message.sender === 'user'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-800'
                }`}
              >
                <p className="text-base whitespace-pre-wrap">{message.text}</p>
                <p className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
              
              {message.sender === 'user' && (
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center">
                  <div className="w-full h-full bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-base">U</span>
                  </div>
                </div>
              )}
              
              {message.sender === 'ai' && (
                <div className="w-12 h-12 flex-shrink-0"></div>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="chat-input-container border-t p-4">
        <div className="flex gap-2">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="メッセージを入力..."
            className="flex-1 p-2 border rounded-lg resize-none"
            rows={2}
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            送信
          </button>
        </div>
      </div>
    </div>
  )
}