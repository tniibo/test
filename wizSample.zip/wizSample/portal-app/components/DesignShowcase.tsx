'use client'

import { useState } from 'react'

export default function DesignShowcase() {
  const [selectedOption, setSelectedOption] = useState('option1')
  const [selectedRadio, setSelectedRadio] = useState('radio1')
  const [selectedHorizontalRadio, setSelectedHorizontalRadio] = useState('horizontal1')
  const [checkboxes, setCheckboxes] = useState({
    option1: true,
    option2: false,
    option3: true,
    option4: false
  })
  const [textValue, setTextValue] = useState('')
  const [searchValue, setSearchValue] = useState('')
  const [passwordValue, setPasswordValue] = useState('')
  const [textareaValue, setTextareaValue] = useState('')

  const handleCheckboxChange = (option: string) => {
    setCheckboxes(prev => ({
      ...prev,
      [option]: !prev[option as keyof typeof prev]
    }))
  }

  return (
    <div className="design-showcase space-y-8">
      {/* ボタンセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">ボタン</h2>
        <div className="flex flex-wrap gap-4">
          <button className="btn-primary px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-plus"></span>
            <span>プライマリボタン</span>
          </button>
          <button className="btn-secondary px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-settings"></span>
            <span>セカンダリボタン</span>
          </button>
          <button className="btn-danger px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-trash"></span>
            <span>削除ボタン</span>
          </button>
          <button className="btn-success px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-save"></span>
            <span>保存ボタン</span>
          </button>
          <button className="btn-disabled px-4 py-2 rounded flex items-center gap-2" disabled>
            <span className="icon icon-ban"></span>
            <span>無効ボタン</span>
          </button>
        </div>
        <div className="flex flex-wrap gap-4 mt-4">
          <button className="btn-primary px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-add"></span>
            <span>新規追加</span>
          </button>
          <button className="btn-secondary px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-edit"></span>
            <span>編集</span>
          </button>
          <button className="btn-primary px-4 py-2 rounded flex items-center gap-2">
            <span className="icon icon-upload"></span>
            <span>アップロード</span>
          </button>
        </div>
      </section>

      {/* テーブルセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">テーブル</h2>
        <div className="overflow-x-auto">
          <table className="showcase-table w-full">
            <thead>
              <tr>
                <th className="text-left p-3">ID</th>
                <th className="text-left p-3">名前</th>
                <th className="text-left p-3">メールアドレス</th>
                <th className="text-left p-3">ステータス</th>
                <th className="text-left p-3">アクション</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="p-3">001</td>
                <td className="p-3">山田太郎</td>
                <td className="p-3">yamada@example.com</td>
                <td className="p-3">
                  <span className="status-active px-2 py-1 rounded text-sm">アクティブ</span>
                </td>
                <td className="p-3">
                  <button className="text-blue-500 hover:underline mr-2">編集</button>
                  <button className="text-red-500 hover:underline">削除</button>
                </td>
              </tr>
              <tr>
                <td className="p-3">002</td>
                <td className="p-3">鈴木花子</td>
                <td className="p-3">suzuki@example.com</td>
                <td className="p-3">
                  <span className="status-inactive px-2 py-1 rounded text-sm">非アクティブ</span>
                </td>
                <td className="p-3">
                  <button className="text-blue-500 hover:underline mr-2">編集</button>
                  <button className="text-red-500 hover:underline">削除</button>
                </td>
              </tr>
              <tr>
                <td className="p-3">003</td>
                <td className="p-3">佐藤次郎</td>
                <td className="p-3">sato@example.com</td>
                <td className="p-3">
                  <span className="status-pending px-2 py-1 rounded text-sm">保留中</span>
                </td>
                <td className="p-3">
                  <button className="text-blue-500 hover:underline mr-2">編集</button>
                  <button className="text-red-500 hover:underline">削除</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* テキストボックスセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">テキストボックス</h2>
        <div className="space-y-6 max-w-2xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block mb-2 font-medium">通常のテキストボックス</label>
              <input
                type="text"
                className="text-input w-full p-3 rounded border"
                placeholder="テキストを入力してください"
                value={textValue}
                onChange={(e) => setTextValue(e.target.value)}
              />
            </div>
            <div>
              <label className="block mb-2 font-medium">検索可能なテキストボックス</label>
              <div className="search-input-container relative">
                <input
                  type="search"
                  className="search-input w-full p-3 pl-10 rounded border"
                  placeholder="検索キーワードを入力"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
                <span className="search-icon absolute left-3 top-1/2 transform -translate-y-1/2">
                  🔍
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block mb-2 font-medium">パスワード入力</label>
              <input
                type="password"
                className="text-input w-full p-3 rounded border"
                placeholder="パスワードを入力"
                value={passwordValue}
                onChange={(e) => setPasswordValue(e.target.value)}
              />
            </div>
            <div>
              <label className="block mb-2 font-medium">無効なテキストボックス</label>
              <input
                type="text"
                className="text-input w-full p-3 rounded border"
                placeholder="入力不可"
                disabled
              />
            </div>
          </div>

          <div>
            <label className="block mb-2 font-medium">テキストエリア</label>
            <textarea
              className="textarea w-full p-3 rounded border resize-y"
              rows={4}
              placeholder="複数行のテキストを入力してください"
              value={textareaValue}
              onChange={(e) => setTextareaValue(e.target.value)}
            />
          </div>

          <div>
            <label className="block mb-2 font-medium">エラー状態のテキストボックス</label>
            <input
              type="email"
              className="text-input text-input-error w-full p-3 rounded border"
              placeholder="メールアドレスを入力"
              defaultValue="invalid-email"
            />
            <p className="text-red-500 text-sm mt-1">正しいメールアドレスを入力してください</p>
          </div>

          <div>
            <label className="block mb-2 font-medium">成功状態のテキストボックス</label>
            <input
              type="email"
              className="text-input text-input-success w-full p-3 rounded border"
              placeholder="メールアドレスを入力"
              defaultValue="user@example.com"
            />
            <p className="text-green-500 text-sm mt-1">有効なメールアドレスです</p>
          </div>
        </div>
      </section>

      {/* プルダウンセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">プルダウン</h2>
        <div className="space-y-4 max-w-md">
          <div>
            <label className="block mb-2">基本的なプルダウン</label>
            <select className="dropdown w-full p-2 rounded border" value={selectedOption} onChange={(e) => setSelectedOption(e.target.value)}>
              <option value="option1">オプション1</option>
              <option value="option2">オプション2</option>
              <option value="option3">オプション3</option>
              <option value="option4">オプション4</option>
            </select>
          </div>
          <div>
            <label className="block mb-2">無効なプルダウン</label>
            <select className="dropdown w-full p-2 rounded border" disabled>
              <option>選択不可</option>
            </select>
          </div>
        </div>
      </section>

      {/* ラジオボタンセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">ラジオボタン</h2>
        <div className="space-y-3 max-w-md">
          <div>
            <label className="block mb-3 font-semibold">通知設定を選択してください</label>
            <div className="space-y-2">
              {[
                { value: 'radio1', label: 'すべての通知を受け取る', description: 'メール・プッシュ通知すべて' },
                { value: 'radio2', label: '重要な通知のみ', description: 'システム通知とエラーのみ' },
                { value: 'radio3', label: '通知を無効にする', description: 'すべての通知を停止' }
              ].map((option) => (
                <label key={option.value} className="radio-option flex items-start p-3 rounded cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="notificationSettings"
                    value={option.value}
                    checked={selectedRadio === option.value}
                    onChange={(e) => setSelectedRadio(e.target.value)}
                    className="radio-input mt-1 mr-3"
                  />
                  <div>
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500 mt-1">{option.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t">
            <label className="block mb-3 font-semibold">表示形式を選択（横並び）</label>
            <div className="flex flex-wrap gap-6">
              {[
                { value: 'horizontal1', label: 'リスト表示' },
                { value: 'horizontal2', label: 'カード表示' },
                { value: 'horizontal3', label: 'テーブル表示' },
                { value: 'horizontal4', label: 'グリッド表示' }
              ].map((option) => (
                <label key={option.value} className="radio-option-horizontal flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="displayFormat"
                    value={option.value}
                    checked={selectedHorizontalRadio === option.value}
                    onChange={(e) => setSelectedHorizontalRadio(e.target.value)}
                    className="radio-input mr-2"
                  />
                  <span className="font-medium">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* チェックボックスセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">チェックボックス</h2>
        <div className="space-y-3 max-w-md">
          <div>
            <label className="block mb-3 font-semibold">機能設定</label>
            <div className="space-y-2">
              {[
                { key: 'option1', label: 'ダークモード', description: '暗いテーマを使用' },
                { key: 'option2', label: '自動保存', description: '変更を自動的に保存' },
                { key: 'option3', label: 'キーボードショートカット', description: 'ショートカットキーを有効化' },
                { key: 'option4', label: 'デバッグモード', description: '開発者向け情報を表示' }
              ].map((option) => (
                <label key={option.key} className="checkbox-option flex items-start p-3 rounded cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={checkboxes[option.key as keyof typeof checkboxes]}
                    onChange={() => handleCheckboxChange(option.key)}
                    className="checkbox-input mt-1 mr-3"
                  />
                  <div>
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500 mt-1">{option.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>
          
          <div className="pt-4 border-t">
            <label className="block mb-3 font-semibold">簡単な選択肢</label>
            <div className="flex flex-wrap gap-4">
              <label className="checkbox-simple flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="checkbox-input mr-2" />
                <span>メール通知</span>
              </label>
              <label className="checkbox-simple flex items-center cursor-pointer">
                <input type="checkbox" className="checkbox-input mr-2" />
                <span>SMS通知</span>
              </label>
              <label className="checkbox-simple flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="checkbox-input mr-2" />
                <span>プッシュ通知</span>
              </label>
              <label className="checkbox-simple flex items-center cursor-pointer">
                <input type="checkbox" disabled className="checkbox-input mr-2" />
                <span>無効な選択肢</span>
              </label>
            </div>
          </div>
        </div>
      </section>

      {/* カードセクション */}
      <section className="showcase-section">
        <h2 className="text-xl font-bold mb-4">カード</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="showcase-card p-6 rounded-lg">
            <h3 className="font-bold mb-2">基本カード</h3>
            <p className="text-sm mb-4">これは基本的なカードデザインです。情報を整理して表示するのに適しています。</p>
            <button className="btn-primary px-4 py-2 rounded text-sm flex items-center gap-2">
              <span className="icon icon-eye"></span>
              <span>詳細を見る</span>
            </button>
          </div>
          <div className="showcase-card p-6 rounded-lg">
            <div className="card-icon text-3xl mb-3">📊</div>
            <h3 className="font-bold mb-2">アイコン付きカード</h3>
            <p className="text-sm mb-4">アイコンを使用して視覚的にわかりやすくしたカードです。</p>
            <div className="flex gap-2">
              <button className="btn-secondary px-3 py-1 rounded text-sm flex items-center gap-1">
                <span className="icon icon-sm icon-edit"></span>
                <span>編集</span>
              </button>
              <button className="btn-danger px-3 py-1 rounded text-sm flex items-center gap-1">
                <span className="icon icon-sm icon-trash"></span>
                <span>削除</span>
              </button>
            </div>
          </div>
          <div className="showcase-card showcase-card-highlight p-6 rounded-lg">
            <h3 className="font-bold mb-2">ハイライトカード</h3>
            <p className="text-sm mb-4">重要な情報を強調するための特別なデザインのカードです。</p>
            <div className="mt-4 text-2xl font-bold">¥12,345</div>
          </div>
        </div>
      </section>
    </div>
  )
}