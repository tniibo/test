'use client'

import { useRouter } from 'next/navigation'

interface FeatureCardProps {
  title: string
  description: string
  icon: string
  route: string
  color: string
  cardType?: string // カードの種類を識別するためのプロパティ
}

export default function FeatureCard({ title, description, icon, route, color, cardType }: FeatureCardProps) {
  const router = useRouter()

  const handleClick = () => {
    router.push(route)
  }

  // カードタイプに基づいてクラスを追加
  const cardClass = cardType ? `card-${cardType}` : ''
  const additionalClass = title === 'AIチャット' ? 'ai-chat-card' : ''

  return (
    <div
      onClick={handleClick}
      className={`feature-card ${cardClass} ${additionalClass} cursor-pointer rounded-lg p-6 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl ${color}`}
    >
      <div className="feature-card-icon text-4xl mb-4">
        <span className="theme-icon"></span>
        <span className="fallback-icon">{icon}</span>
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-sm">{description}</p>
    </div>
  )
}