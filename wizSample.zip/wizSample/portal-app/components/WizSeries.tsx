'use client'

import { useState } from 'react'
import Image from 'next/image'

export default function WizSeries() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)
  
  const wizProducts = [
    {
      name: 'Wiz-Grimoire',
      description: 'ユーザーツールに埋め込み可能なAPI提供',
      features: ['スペルテンプレート管理', '魔法レシピ検索', '古代知識アーカイブ'],
      status: '開発中',
      icon: '/Wiz-Grimoire.svg',
      color: 'green'
    },
    {
      name: 'Wiz-Chronicle',
      description: 'プロジェクトマネージメントツール',
      features: ['時系列イベント記録', '伝説アーカイブ', '古代文書解読'],
      status: '開発中',
      icon: '/Wiz-Chronicle.svg',
      color: 'orange'
    },
    {
      name: 'Wiz-COBOL',
      description: 'COBOLエディタ',
      features: ['VSCode風開発環境', 'AIコーディング支援'],
      status: '開発中',
      icon: '/Wiz-COBOL.svg',
      color: 'purple'
    },
    {
      name: 'Wiz-Lore',
      description: '魔法知識データベース',
      features: ['知識グラフ作成', '古代資料連携', '智恵推論エンジン'],
      status: '開発中',
      icon: '/Wiz-Lore.svg',
      color: 'darkgreen'
    },
    {
      name: 'Wiz-Sprite',
      description: '魔法精霊アシスタント',
      features: ['自動タスク実行', '知能対話システム', '魔法ワークフロー'],
      status: '開発中',
      icon: '/Wiz-Sprite.svg',
      color: 'blue'
    },
    {
      name: 'Wiz-Plugins',
      description: '魔法拡張プラグインシステム',
      features: ['モジュール管理', 'カスタムスペル作成', 'サードパーティ連携'],
      status: '開発中',
      icon: '/Wiz-Plugins.svg',
      color: 'darkblue'
    }
  ]

  return (
    <div className="wiz-series-container">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4 wiz-title">Wizシリーズ製品ラインナップ</h2>
        <p className="text-lg wiz-subtitle">魔法のように業務を効率化する統合ソリューション</p>
      </div>

      <div className="wiz-card-area">
        {wizProducts.map((product, index) => (
          <section key={index} className="wiz-card-section">
            <div 
              className="wiz-card"
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className="wiz-flip-card">
                <div className={`wiz-flip-card__container ${hoveredCard === index ? 'flipped' : ''}`}>
                  <div className="wiz-card-front">
                    <div className={`wiz-card-front__tp wiz-card-front__tp--${product.color}`}>
                      {(product.icon.endsWith('.png') || product.icon.endsWith('.svg')) ? (
                        <div className="wiz-card-front__icon">
                          <Image 
                            src={product.icon} 
                            alt={product.name} 
                            width={60} 
                            height={60}
                            className="object-contain"
                          />
                        </div>
                      ) : (
                        <span className="wiz-card-front__icon">{product.icon}</span>
                      )}
                      <h2 className="wiz-card-front__heading">
                        {product.name}
                      </h2>
                      <p className="wiz-card-front__status">
                        {product.status}
                      </p>
                    </div>
                    <div className="wiz-card-front__bt">
                      <p className={`wiz-card-front__text-view wiz-card-front__text-view--${product.color}`}>
                        View Details
                      </p>
                    </div>
                  </div>
                  <div className="wiz-card-back">
                    <div className="wiz-card-back__content">
                      <h3 className="wiz-card-back__heading">{product.description}</h3>
                      <ul className="wiz-card-back__features">
                        {product.features.map((feature, fIndex) => (
                          <li key={fIndex}>{feature}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="wiz-inside-page">
                <div className="wiz-inside-page__container">
                  <h3 className={`wiz-inside-page__heading wiz-inside-page__heading--${product.color}`}>
                    {product.name}
                  </h3>
                  <p className="wiz-inside-page__text">
                    {product.description}
                  </p>
                  <div className="wiz-inside-page__features">
                    <h4 className="font-semibold mb-2">主な機能:</h4>
                    <ul className="space-y-1">
                      {product.features.map((feature, fIndex) => (
                        <li key={fIndex} className="text-sm">✨ {feature}</li>
                      ))}
                    </ul>
                  </div>
                  <button className={`wiz-inside-page__btn wiz-inside-page__btn--${product.color}`}>詳細を見る</button>
                </div>
              </div>
            </div>
          </section>
        ))}
      </div>

      <div className="wiz-stats-section rounded-lg p-6">
        <h3 className="text-xl font-bold mb-4">システム統計</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="stat-card text-center p-4 rounded">
            <div className="text-3xl font-bold stat-number">1,234</div>
            <div className="text-sm mt-1">アクティブユーザー</div>
          </div>
          <div className="stat-card text-center p-4 rounded">
            <div className="text-3xl font-bold stat-number">98.5%</div>
            <div className="text-sm mt-1">システム稼働率</div>
          </div>
          <div className="stat-card text-center p-4 rounded">
            <div className="text-3xl font-bold stat-number">456</div>
            <div className="text-sm mt-1">API連携数</div>
          </div>
          <div className="stat-card text-center p-4 rounded">
            <div className="text-3xl font-bold stat-number">24/7</div>
            <div className="text-sm mt-1">サポート体制</div>
          </div>
        </div>
      </div>
    </div>
  )
}